# A203. 단어 길이 재기 - Baekjoon

str = input()

print(len(str))