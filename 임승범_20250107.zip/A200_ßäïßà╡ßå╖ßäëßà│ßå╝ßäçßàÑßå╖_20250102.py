# A200. 돌 게임 2 - Baekjoon

N = int(input())

if (N % 2 == 0):
    print("SK")
else:
    print("CY")